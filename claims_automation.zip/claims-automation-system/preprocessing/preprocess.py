import pandas as pd

def preprocess_claim_data(filepath):
    df = pd.read_csv(filepath)
    df = df.fillna("Unknown")
    return df
import joblib

def load_model(model_path="/content/claims-automation-system/classification/complexity_classifier.joblib"):
    return joblib.load(model_path)

def route_claim(model, claim_features):
    prediction = model.predict([claim_features])[0]
    score = model.predict_proba([claim_features])[0][1]

    if prediction == 0:
        return "✅ Auto-Processed"
    else:
        return f"🛠️ Routed to Human Review (Priority Score: {score:.2f})"
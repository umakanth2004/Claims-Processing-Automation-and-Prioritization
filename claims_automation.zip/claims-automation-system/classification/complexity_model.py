from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib

def train_complexity_model(df):
    df['complexity'] = ((df['total_claim_amount'] > 25000) |
                        (df['number_of_vehicles_involved'] > 1) |
                        (df['bodily_injuries'] > 0)).astype(int)
    
    features = ['total_claim_amount', 'number_of_vehicles_involved', 'bodily_injuries']
    X = df[features]
    y = df['complexity']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)

    print(classification_report(y_test, model.predict(X_test)))
    joblib.dump(model, "/content/claims-automation-system/classification/complexity_classifier.joblib")

    return model
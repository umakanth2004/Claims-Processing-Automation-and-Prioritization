import matplotlib.pyplot as plt
import seaborn as sns

def visualize_claim_complexity(df):
    sns.set(style="whitegrid")

    df['complexity'] = ((df['total_claim_amount'] > 25000) |
                        (df['number_of_vehicles_involved'] > 1) |
                        (df['bodily_injuries'] > 0)).astype(int)

    # 1. Bar plot
    plt.figure(figsize=(5, 4))
    sns.countplot(x='complexity', data=df, palette='coolwarm')
    plt.xticks([0, 1], ['Simple', 'Complex'])
    plt.title('Claim Complexity Distribution')
    plt.tight_layout()
    plt.savefig("/content/claims-automation-system/images/complexity_distribution.png")
    plt.close()

    # 2. Boxplot
    plt.figure(figsize=(6, 4))
    sns.boxplot(x='complexity', y='total_claim_amount', data=df, palette='Set3')
    plt.xticks([0, 1], ['Simple', 'Complex'])
    plt.title('Total Claim Amount by Complexity')
    plt.tight_layout()
    plt.savefig("/content/claims-automation-system/images/claim_amount_vs_complexity.png")
    plt.close()
def extract_relevant_fields(df):
    fields = [
        'total_claim_amount',
        'number_of_vehicles_involved',
        'bodily_injuries',
        'witnesses',
        'injury_claim',
        'property_claim'
    ]
    return df[[col for col in fields if col in df.columns]]